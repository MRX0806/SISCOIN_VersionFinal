document.addEventListener("DOMContentLoaded", () => {
    const urlParams = new URLSearchParams(window.location.search);
    const temaId = urlParams.get('tema_id');
    document.getElementById('tema_id').value = temaId;

    // Obtener nombre del tema
    fetch(`http://localhost:8080/api/temas/${temaId}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok ' + response.statusText);
            }
            return response.json();
        })
        .then(data => {
            console.log('Tema recibido:', data); // Agregar log
            const temaSeleccionadoDiv = document.getElementById('tema-seleccionado');
            if (data.error) {
                temaSeleccionadoDiv.innerHTML = `<p>${data.error}</p>`;
            } else {
                temaSeleccionadoDiv.innerHTML = `<p>El tema seleccionado es: ${data.nombre}</p>`;
            }
        })
        .catch(error => console.error('Error fetching tema:', error));

    // Obtener comentarios del tema
    fetch(`http://localhost:8080/api/temas/${temaId}/comentarios`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok ' + response.statusText);
            }
            return response.json();
        })
        .then(data => {
            console.log('Comentarios recibidos:', data); // Agregar log
            const comentariosDiv = document.getElementById('comentarios');
            if (data.error) {
                comentariosDiv.innerHTML = `<p>${data.error}</p>`;
            } else {
                data.forEach(comentario => {
                    const p = document.createElement('p');
                    p.innerHTML = `<strong>${comentario.fecha}:</strong> ${comentario.comentario}`;
                    comentariosDiv.appendChild(p);
                });
            }
        })
        .catch(error => console.error('Error fetching comentarios:', error));

    // Obtener usuarios activos
    fetch('http://localhost:8080/api/usuarios')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok ' + response.statusText);
            }
            return response.json();
        })
        .then(data => {
            console.log('Usuarios activos recibidos:', data); // Agregar log
            const usuariosActivosDiv = document.getElementById('usuarios-activos');
            if (data.error) {
                usuariosActivosDiv.innerHTML = `<p>${data.error}</p>`;
            } else {
                const ul = document.createElement('ul');
                data.forEach(usuario => {
                    const li = document.createElement('li');
                    li.textContent = usuario.nombre_completo;
                    ul.appendChild(li);
                });
                usuariosActivosDiv.appendChild(ul);
            }
        })
        .catch(error => console.error('Error fetching usuarios activos:', error));
});


/*
    // Manejar el envío de comentarios
    document.getElementById('form-comentario').addEventListener('submit', function(event) {
        event.preventDefault();
        let comentario = document.getElementById('comentario').value;

        fetch(`http://localhost:8080/api/comentarios`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ comentario: comentario, tema_id: temaId }),
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                alert(data.message);
                document.getElementById('form-comentario').reset();
                // Recargar los comentarios después de agregar uno nuevo
                fetch(`http://localhost:8080/api/temas/${temaId}/comentarios`)
                    .then(response => response.json())
                    .then(data => {
                        console.log('Comentarios recibidos:', data); // Agregar log
                        const comentariosDiv = document.getElementById('comentarios');
                        comentariosDiv.innerHTML = ''; // Limpiar contenido anterior
                        if (data.error) {
                            comentariosDiv.innerHTML = `<p>${data.error}</p>`;
                        } else {
                            data.forEach(comentario => {
                                const p = document.createElement('p');
                                p.innerHTML = `<strong>${comentario.fecha}:</strong> ${comentario.comentario}`;
                                comentariosDiv.appendChild(p);
                            });
                        }
                    })
                    .catch(error => console.error('Error fetching comentarios:', error));
            } else {
                alert(data.message);
            }
        })
        .catch(error => console.error('Error:', error));
    });
*/